package com.example.lms.prompt;

import com.example.lms.service.rag.pre.CognitiveState;
import dev.langchain4j.rag.content.Content;
import dev.langchain4j.data.document.Document;

import java.util.*;

/**
 * 프롬프트 생성 전 과정을 관통하는 '명시적 대화 맥락' DTO (Data Transfer Object).
 * 불변성을 보장하기 위해 Java record로 정의되었으며, 손쉬운 객체 생성을 위해 빌더 패턴을 제공합니다.
 */
public record PromptContext(
        // ───── 1. 대화 상태 ─────
        String userQuery,
        String lastAssistantAnswer,   // 직전 AI 답변 (후속 질문 처리의 핵심 앵커)
        String history,               // 최근 대화 히스토리 (문자열로 조인된 형태)

        // ───── 2. 증거 (컨텍스트) ─────
        List<Content> web,            // 라이브 웹/하이브리드 검색 결과
        List<Content> rag,            // 벡터 DB 검색 결과
        String memory,                // 장기 메모리 (요약 또는 스니펫)
        /**
         * When a user uploads a file, its extracted plain‑text contents are stored here.
         * This context has the highest authority in the prompt and is injected before any
         * other sources.  If no file is uploaded, this value will be {@code null}.
         */
        String fileContext,
        /**
         * Optional location context captured from the client.  When present the assistant
         * can reason about the user’s current position.  If the client has not
         * granted location consent or no recent location exists this value will be
         * {@code null}.  See {@link LocationSection} for field definitions.
         */
        LocationSection location,
        /**
         * Resolved human readable address associated with the user’s most recent location.
         * When present the assistant can include a natural language description of the
         * user’s location in the prompt instead of just raw coordinates.  This value
         * may be null when no reverse geocoding has been performed or consent is absent.
         */
        String locationAddress,

        // ───── 3. 도메인 및 규칙 ─────
        String domain,                
        java.util.List<String> systemHints,
        // 현재 대화의 도메인 (예: "Genshin Impact")
        String intent,                // 사용자의 의도 (예: "PAIRING", "RECOMMENDATION")
        String subject,               // 대화의 핵심 주제 (예: "Nahida")
        Set<String> protectedTerms,   // 원본 형태를 유지해야 할 고유명사
        Map<String, Set<String>> interactionRules, // 동적으로 적용될 관계 규칙
        CognitiveState cognitiveState,  // ✅ [추가] 인지 상태(추상도/증거/시간/복잡도)

        // ───── 4. 출력 정책 ─────
        String verbosityHint,         // 답변 상세도 힌트 (brief, standard, deep, ultra)
        Integer minWordCount,         // 최소 답변 단어 수 강제
        List<String> sectionSpec,     // 답변에 포함될 섹션 헤더 목록 강제
        Integer targetTokenBudgetOut, // 모델의 출력 토큰 예산
        String audience,              // 답변의 대상 독자층 (예: "초보자")
        String citationStyle,         // 출처 표기 스타일 (예: "inline", "footnote")
        List<String> unsupportedClaims,   // 🆕 치유 단계에서 전달될 '미지원 주장' 목록
        String systemInstruction          // 🆕 특수 지시(예: "CORRECTIVE_REGENERATION")
        , java.util.List<Document> localDocs
        , java.util.List<Document> ragDocs
        , Boolean ragEnabled
        , Boolean webEnabled
) {

    /**
     * PromptContext 객체를 생성하기 위한 빌더 인스턴스를 반환합니다.
     * @return 새로운 Builder 인스턴스
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * PromptContext 객체를 안전하고 편리하게 생성하기 위한 Builder 클래스.
     */
    public static final class Builder {
        public Builder addSystemHint(String hint) {
            if (hint == null || hint.isBlank()) return this;
            if (this.systemHints == null) this.systemHints = new java.util.ArrayList<>();
            this.systemHints.add(hint.strip());
            return this;
        }

        private String userQuery;
        private String lastAssistantAnswer;
        private String history;
        private List<Content> web = Collections.emptyList();
        private List<Content> rag = Collections.emptyList();
        private String memory;
        private String fileContext;              // uploaded file plain text (nullable)
        private String domain;
        // nullable; 빌더/조립 시 불변 복사로 외부 노출
        private java.util.List<String> systemHints;
        private String intent;
        private String subject;
        private Set<String> protectedTerms = Collections.emptySet();
        private Map<String, Set<String>> interactionRules = Collections.emptyMap();
        private CognitiveState cognitiveState; // ✅ [추가]
        private String verbosityHint = "standard";
        private Integer minWordCount;
        private List<String> sectionSpec = Collections.emptyList();
        private Integer targetTokenBudgetOut;
        private String audience;
        private String citationStyle = "inline";
        private List<String> unsupportedClaims = Collections.emptyList(); // 🆕
        private String systemInstruction;                                  // 🆕
        /**
         * Resolved human readable address associated with the user’s last location.
         * This field is optional and may be null when no reverse geocoding has been
         * performed or the user has not consented to location sharing.
         */
        private String locationAddress;
        /**
         * Latest location section attached to this context.  When present the assistant
         * can reason about the user’s current geographical coordinates.  This value is
         * optional and may be null when no location consent has been granted or when
         * there is no recent location on record.
         */
        private LocationSection location;

        // ───── 추가: 첨부 및 벡터 문서 ─────
        /** Documents extracted from uploaded attachments.  These are injected
         * into the prompt before any other evidence sources and treated as
         * ground truth.  Defaults to an empty list when no attachments are
         * provided. */
        private java.util.List<Document> localDocs = java.util.Collections.emptyList();
        /** Documents retrieved from the vector database when RAG is enabled.
         * Defaults to an empty list. */
        private java.util.List<Document> ragDocs = java.util.Collections.emptyList();
        /** Toggle indicating whether RAG retrieval should be executed.  When
         * true the retriever may be invoked; when false no vector search
         * should occur. */
        private Boolean ragEnabled;
        /** Toggle indicating whether live/hybrid web search should be
         * executed.  This flag is independent of RAG and can be enabled
         * explicitly by the client. */
        private Boolean webEnabled;
        public Builder userQuery(String v) { this.userQuery = v; return this; }
        public Builder lastAssistantAnswer(String v) { this.lastAssistantAnswer = v; return this; }
        public Builder history(String v) { this.history = v; return this; }
        public Builder web(List<Content> v) { this.web = (v == null ? Collections.emptyList() : v); return this; }
        public Builder rag(List<Content> v) { this.rag = (v == null ? Collections.emptyList() : v); return this; }
        public Builder memory(String v) { this.memory = v; return this; }
        public Builder fileContext(String v) { this.fileContext = v; return this; }
        public Builder domain(String v) { this.domain = v; return this; }
        public Builder intent(String v) { this.intent = v; return this; }
        public Builder subject(String v) { this.subject = v; return this; }
        public Builder protectedTerms(Set<String> v) { this.protectedTerms = (v == null ? Collections.emptySet() : v); return this; }
        public Builder interactionRules(Map<String, Set<String>> v) { this.interactionRules = (v == null ? Collections.emptyMap() : v); return this; }
        public Builder cognitiveState(CognitiveState v) { this.cognitiveState = v; return this; } // ✅ [추가]
        public Builder verbosityHint(String v) { this.verbosityHint = (v == null || v.isBlank() ? "standard" : v); return this; }
        public Builder minWordCount(Integer v) { this.minWordCount = v; return this; }
        public Builder sectionSpec(List<String> v) { this.sectionSpec = (v == null ? Collections.emptyList() : v); return this; }
        public Builder targetTokenBudgetOut(Integer v) { this.targetTokenBudgetOut = v; return this; }
        public Builder audience(String v) { this.audience = v; return this; }
        public Builder citationStyle(String v) { this.citationStyle = (v == null || v.isBlank() ? "inline" : v); return this; }

        /**
         * Assign a resolved human readable address to this context.  When blank or null
         * the address will not be included in the LOCATION CONTEXT section of the
         * generated prompt.
         *
         * @param v the resolved address line or null/blank to clear
         * @return this builder for method chaining
         */
        public Builder locationAddress(String v) {
            this.locationAddress = (v == null || v.isBlank() ? null : v);
            return this;
        }

        /**
         * Attach a prebuilt {@link LocationSection} to this context.  When provided
         * the location will be available to downstream prompt builders via
         * {@code ctx.location()}.  Passing {@code null} clears any previously set
         * location.
         */
        public Builder location(LocationSection v) { this.location = v; return this; }

        /**
         * Convenience method to attach a {@link com.example.lms.location.domain.LastLocation}
         * entity as the location section.  When the entity is non-null its
         * properties are copied into a new {@link LocationSection} instance.
         *
         * @param loc the last known location or null
         * @return this builder for chaining
         */
        public Builder withLocation(com.example.lms.location.domain.LastLocation loc) {
            if (loc != null) {
                this.location = new LocationSection(
                        loc.getLatitude(),
                        loc.getLongitude(),
                        loc.getAccuracy(),
                        loc.getCapturedAt()
                );
            } else {
                this.location = null;
            }
            return this;
        }

        /** Assign the list of documents derived from uploaded attachments.  When
         * null or empty the list is set to an empty list to avoid null checks.
         *
         * @param v documents representing attachment content
         * @return this builder for chaining
         */
        public Builder localDocs(java.util.List<Document> v) {
            this.localDocs = (v == null ? java.util.Collections.emptyList() : v);
            return this;
        }

        /** Assign the list of documents retrieved from the vector database.  When
         * null or empty the list is set to an empty list.
         *
         * @param v documents from vector retrieval
         * @return this builder for chaining
         */
        public Builder ragDocs(java.util.List<Document> v) {
            this.ragDocs = (v == null ? java.util.Collections.emptyList() : v);
            return this;
        }

        /** Enable or disable RAG retrieval for this context.  When null the
         * downstream handler may fall back to a configured default.
         *
         * @param v true to enable vector retrieval, false to disable
         * @return this builder for chaining
         */
        public Builder ragEnabled(Boolean v) {
            this.ragEnabled = v;
            return this;
        }

        /** Enable or disable web search for this context.  When null the
         * downstream handler may fall back to a configured default.
         *
         * @param v true to enable web search, false to disable
         * @return this builder for chaining
         */
        public Builder webEnabled(Boolean v) {
            this.webEnabled = v;
            return this;
        }

        public Builder unsupportedClaims(List<String> v) { this.unsupportedClaims = (v == null ? Collections.emptyList() : v); return this; } // 🆕
        public Builder systemInstruction(String v) { this.systemInstruction = (v == null ? "" : v.trim()); return this; }                     // 🆕
        /**
         * 빌더에 설정된 값들을 바탕으로 최종적인 PromptContext 불변 객체를 생성합니다.
         * @return 생성된 PromptContext 인스턴스
         */
        public PromptContext build() {
            return new PromptContext(
                    userQuery,
                    lastAssistantAnswer,
                    history,
                    web,
                    rag,
                    memory,
                    fileContext,
                    location,
                    locationAddress,
                    domain,
                systemHints == null ? java.util.List.of() : java.util.List.copyOf(systemHints),
                    intent,
                    subject,
                    protectedTerms,
                    interactionRules,
                    cognitiveState,
                    verbosityHint,
                    minWordCount,
                    sectionSpec,
                    targetTokenBudgetOut,
                    audience,
                    citationStyle,
                    unsupportedClaims,
                    systemInstruction,
                    localDocs,
                    ragDocs,
                    ragEnabled,
                    webEnabled
            );
        }
    }

    /**
     * Nested record representing a geospatial location captured from the client.  This
     * structure encapsulates latitude, longitude, accuracy and the timestamp when
     * the location was recorded.  Instances of this record are immutable and can
     * be safely shared across threads.  When included in a {@link PromptContext}
     * the assistant may choose to render a LOCATION CONTEXT section in the
     * generated prompt.
     *
     * @param lat        the latitude coordinate (WGS84)
     * @param lng        the longitude coordinate (WGS84)
     * @param accuracy   the accuracy of the location in meters
     * @param capturedAt the timestamp when the location was recorded
     */
    public static record LocationSection(double lat, double lng, float accuracy, java.time.Instant capturedAt) {}
}